# Security checklist

- Browser: only use Supabase publishable key.
- Never put `service_role` or `sb_secret_*` in Vite env vars.
- RLS is enabled in the SQL migration.
- Use signed URLs for private media.
- Validate uploads by MIME type, size and extension.
- Keep moderation/admin operations server-side.
- Add rate limits for comments, uploads, views and auth.
- Store OAuth client secrets only in Supabase/Cloudflare secret settings.
- Rotate credentials if a secret is accidentally exposed.
