import { useEffect, useMemo, useState } from "react";
import { Link, Route, Routes, useLocation, useNavigate, useParams } from "react-router-dom";
import {
  Bell, Search, Menu, Home as HomeIcon, Film, Radio, Library, UserCircle,
  Play, Plus, ThumbsUp, ThumbsDown, Share2, Download, ChevronRight, Settings,
  Upload, LogIn, LogOut, Shield, Wifi, WifiOff, X, Heart, MessageCircle,
  MoreVertical, Sparkles, Clapperboard, BarChart3, Bookmark, Trash2
} from "lucide-react";
import { media, channels, Media } from "./data";
import { supabase, supabaseConfigured } from "./lib/supabase";

const nav = [
  ["/","Home",HomeIcon],[ "/shorts","Shorts",Sparkles],[ "/movies","Movies",Film],
  ["/live","Live",Radio],[ "/library","Library",Library]
] as const;

function Logo(){ return <Link className="logo" to="/"><span className="skull">☠</span><span>SCARY<span>BOX</span></span></Link> }

function App(){
  const [online,setOnline]=useState(navigator.onLine);
  const [user,setUser]=useState<any>(null);
  useEffect(()=>{
    const on=()=>setOnline(true), off=()=>setOnline(false);
    addEventListener("online",on); addEventListener("offline",off);
    if(supabase){ supabase.auth.getSession().then(({data})=>setUser(data.session?.user ?? null));
      const {data:sub}=supabase.auth.onAuthStateChange((_e,s)=>setUser(s?.user ?? null));
      return ()=>{sub.subscription.unsubscribe();removeEventListener("online",on);removeEventListener("offline",off)}
    }
    return ()=>{removeEventListener("online",on);removeEventListener("offline",off)}
  },[]);
  return <div className="app">
    <header><div className="mobile-menu"><Menu size={22}/></div><Logo/>
      <div className="top-search"><Search size={18}/><input placeholder="Search movies, videos, channels..." /></div>
      <div className="top-actions"><Link to="/studio" title="Create"><Upload size={20}/></Link><Link to="/notifications"><Bell size={20}/></Link><Link to={user?"/profile":"/auth"}><UserCircle size={23}/></Link></div>
    </header>
    <div className="network">{online?<><Wifi size={14}/> Online</>:<><WifiOff size={14}/> Offline mode</>}{!supabaseConfigured&&<span>Demo data active</span>}</div>
    <main><Routes>
      <Route path="/" element={<Home/>}/><Route path="/movies" element={<Movies/>}/><Route path="/shorts" element={<Shorts/>}/>
      <Route path="/live" element={<Live/>}/><Route path="/library" element={<LibraryPage/>}/><Route path="/profile" element={<Profile/>}/>
      <Route path="/settings" element={<SettingsPage/>}/><Route path="/studio" element={<Studio/>}/><Route path="/auth" element={<Auth/>}/>
      <Route path="/search" element={<SearchPage/>}/><Route path="/watch/:id" element={<Watch/>}/><Route path="/movie/:id" element={<Movie/>}/>
      <Route path="/channel/:name" element={<Channel/>}/><Route path="/notifications" element={<Notifications/>}/>
    </Routes></main>
    <nav className="bottom-nav">{nav.map(([to,label,I])=><Link key={to} className={location.pathname===to?"active":""} to={to}><I size={20}/><span>{label}</span></Link>)}</nav>
  </div>
}

function Section({title,children,more=true}:{title:string;children:any;more?:boolean}){return <section><div className="section-title"><h2>{title}</h2>{more&&<button>See all <ChevronRight size={15}/></button>}</div>{children}</section>}
function Card({m,wide=false}:{m:Media;wide?:boolean}){return <Link to={m.type==="movie"?`/movie/${m.id}`:`/watch/${m.id}`} className={`card ${wide?"wide":""}`}><div className="poster"><img src={m.poster}/><span className="badge">{m.type==="live"?"● LIVE":m.duration}</span>{m.progress&&<i style={{width:`${m.progress}%`}}/>}</div><div className="card-title">{m.title}</div><div className="meta">★ {m.rating||"Live"} · {m.genre} · {m.views}</div></Link>}

function Home(){
  return <div className="page">
    <div className="hero" style={{backgroundImage:`linear-gradient(90deg,#050505 5%,rgba(5,5,5,.5),rgba(5,5,5,.1)),url(${featured[0].poster})`}}>
      <div><div className="eyebrow">SCARYBOX ORIGINAL</div><h1>{featured[0].title}</h1><p>{featured[0].description}</p><div className="hero-buttons"><Link className="btn red" to="/watch/m1"><Play size={17}/> Watch Now</Link><button className="btn"><Plus size={17}/> My List</button></div></div>
    </div>
    <Section title="Trending Now"><div className="row">{media.filter(x=>x.type==="movie").slice(0,6).map(m=><Card key={m.id} m={m}/>)}</div></Section>
    <Section title="Continue Watching"><div className="row">{[media[3],media[6],media[1]].map((m,i)=><Card key={m.id} m={{...m,progress:[42,18,82][i]}}/>)}</div></Section>
    <Section title="Popular Videos"><div className="grid">{media.filter(x=>x.type==="video").map(m=><Card key={m.id} m={m}/>)}</div></Section>
  </div>
}

function Movies(){return <div className="page"><PageHead title="Movies" sub="Fictional demo movies are included so the app is populated immediately."/><div className="chips">{["All","Action","Horror","Comedy","Drama","Thriller"].map(x=><button key={x} className={x==="All"?"selected":""}>{x}</button>)}</div><div className="grid movies">{media.filter(x=>x.type==="movie").map(m=><Card key={m.id} m={m}/>)}</div></div>}
function Shorts(){return <div className="page"><PageHead title="Shorts"/><div className="short-feed">{media.filter(x=>x.type==="short").map(m=><div className="short"><img src={m.poster}/><div className="short-overlay"><b>{m.title}</b><span>#{m.genre.toLowerCase()} #scarybox</span></div><div className="short-actions"><button><Heart/>124K</button><button><MessageCircle/>4.2K</button><button><Share2/>8.7K</button><button className="btn red">Subscribe</button></div></div>)}</div></div>}
function Live(){return <div className="page"><PageHead title="Live"/><div className="chips"><button>Following</button><button className="selected">Popular</button><button>Upcoming</button></div><div className="live-list">{media.filter(x=>x.type==="live"||x.type==="video").map(m=><Card key={m.id} m={{...m,type:"live"}} wide/>)}</div></div>}
function LibraryPage(){return <div className="page"><PageHead title="Library"/><div className="stats"><div><b>12</b><span>Downloads</span></div><div><b>8</b><span>Watchlist</span></div><div><b>24</b><span>History</span></div></div><Section title="Downloads"><div className="row">{media.slice(0,4).map(m=><Card key={m.id} m={m}/>)}</div></Section><Section title="My List"><div className="row">{media.slice(4,8).map(m=><Card key={m.id} m={m}/>)}</div></Section></div>}
function Profile(){return <div className="page"><div className="profile-head"><img src={channels[1].poster}/><div><h1>MunasheDev ✓</h1><p>@MunasheDev · 230K subscribers · 128 videos</p><div className="hero-buttons"><Link className="btn" to="/studio">Creator Studio</Link><button className="btn red">Edit Profile</button></div></div></div><div className="profile-tabs"><b>Videos</b><span>Playlists</span><span>Community</span></div><Section title="My Videos"><div className="grid">{media.slice(0,4).map(m=><Card key={m.id} m={m}/>)}</div></Section></div>}
function SettingsPage(){const [theme,setTheme]=useState(true);return <div className="page"><PageHead title="Settings"/><div className="settings-card"><div className="setting-user"><img src={channels[1].poster}/><div><b>MunasheDev</b><span>munashedev@gmail.com</span></div></div>{["Account","Appearance","Playback","Privacy","Notifications","Storage","Security","Creator Settings"].map((x,i)=><div className="setting" key={x}><span>{[UserCircle,Settings,Play,Shield,Bell,Download,Shield,Clapperboard][i] && (()=>{const I=[UserCircle,Settings,Play,Shield,Bell,Download,Shield,Clapperboard][i];return <I/>})()}</span><div><b>{x}</b><small>{["Profile, Email, Password","Dark mode, Theme, Display","Quality, Captions, Speed","History, Activity, Downloads","Email, Push, Alerts","Downloads, Cache, Usage","Sessions, Two-Factor Auth","Channel, Upload Defaults"][i]}</small></div><ChevronRight/></div>)}<label className="toggle"><span>Dark cinematic theme</span><input type="checkbox" checked={theme} onChange={e=>setTheme(e.target.checked)}/></label></div></div>}
function Studio(){const [uploaded,setUploaded]=useState(false);return <div className="page"><PageHead title="Creator Studio" sub="Manage your channel, uploads and analytics."/><div className="studio-actions"><button className="btn red" onClick={()=>setUploaded(true)}><Upload/> Upload video</button><button className="btn"><Radio/> Go live</button></div>{uploaded&&<div className="notice">Demo upload workflow opened. Connect Supabase Storage to persist real uploads.</div>}<div className="stats"><div><b>1.2M</b><span>Total views</span></div><div><b>230K</b><span>Subscribers</span></div><div><b>542</b><span>Videos</span></div><div><b>4.8%</b><span>Engagement</span></div></div><Section title="Your content"><div className="grid">{media.slice(0,6).map(m=><Card key={m.id} m={m}/>)}</div></Section></div>}
function Auth(){const [mode,setMode]=useState<"login"|"signup">("login");const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [msg,setMsg]=useState("");const submit=async()=>{if(!supabase){setMsg("Demo mode: add VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY to connect your project.");return}const r=mode==="login"?await supabase.auth.signInWithPassword({email,password}):await supabase.auth.signUp({email,password});setMsg(r.error?.message||"Check your email or continue.");};const google=async()=>{if(!supabase){setMsg("Demo mode: configure Supabase first.");return}await supabase.auth.signInWithOAuth({provider:"google",options:{redirectTo:location.origin}})};return <div className="auth"><Logo/><div className="auth-box"><h1>{mode==="login"?"Welcome back":"Create your ScaryBox account"}</h1><p>Use your real Supabase authentication when configured.</p><button className="google" onClick={google}>Continue with Google</button><div className="or">or</div><input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)}/><input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)}/><button className="btn red full" onClick={submit}>{mode==="login"?"Sign in":"Sign up"}</button>{msg&&<div className="notice">{msg}</div>}<button className="link-btn" onClick={()=>setMode(mode==="login"?"signup":"login")}>{mode==="login"?"Create account":"I already have an account"}</button></div></div>}
function SearchPage(){return <div className="page"><PageHead title="Search"/><div className="search-large"><Search/><input autoFocus placeholder="Search ScaryBox" /></div><div className="grid">{media.map(m=><Card key={m.id} m={m}/>)}</div></div>}
function Notifications(){return <div className="page"><PageHead title="Notifications"/>{["ScaryBox Official uploaded The Dark Forest — Trailer","Your download is ready","ShadowHorror posted a new Short","Your channel reached 230K subscribers"].map((x,i)=><div className="notification" key={x}><Bell/><div><b>{x}</b><small>{i+1}h ago</small></div></div>)}</div>}
function Watch(){const {id}=useParams();const m=media.find(x=>x.id===id)||media[0];return <div className="page"><div className="player">{m.videoUrl?<video controls poster={m.poster} src={m.videoUrl}/>:<div className="player-placeholder"><Play size={56}/><span>Demo player — connect your licensed media URL or Supabase Storage file.</span></div>}</div><div className="watch-head"><div><h1>{m.title}</h1><div className="meta">★ {m.rating||"Live"} · {m.views} views · {m.genre} · {m.duration}</div></div><button className="btn red"><Play/> Watch Now</button></div><div className="actions"><button><ThumbsUp/> Like</button><button><ThumbsDown/> Dislike</button><button><Share2/> Share</button><button><Download/> Download</button><button><Plus/> My List</button></div><div className="description"><p>{m.description}</p><b>{m.channel}</b><p>Fictional demo content included with this build. Replace with media you own or have permission to distribute.</p></div></div>}
function Movie(){const {id}=useParams();const m=media.find(x=>x.id===id)||media[0];return <WatchLikeMovie m={m}/>}
function WatchLikeMovie({m}:{m:Media}){return <div className="page movie-detail"><div className="movie-hero" style={{backgroundImage:`linear-gradient(90deg,#050505 10%,rgba(5,5,5,.65),rgba(5,5,5,.2)),url(${m.poster})`}}><div><span className="eyebrow">SCARYBOX ORIGINAL</span><h1>{m.title}</h1><p>{m.year} · {m.duration} · {m.genre} · ★ {m.rating}</p><p>{m.description}</p><Link className="btn red" to={`/watch/${m.id}`}><Play/> Watch Now</Link></div></div><Section title="Cast & Crew"><div className="cast">{["Daniel Cross","Sarah Klein","Michael Rey"].map((x,i)=><div key={x}><img src={channels[i].poster}/><b>{x}</b><span>{["Lead Actor","Lead Actress","Director"][i]}</span></div>)}</div></Section></div>}
function Channel(){const {name}=useParams();const c=channels.find(x=>x.name.toLowerCase()===decodeURIComponent(name||"").toLowerCase())||channels[0];return <div className="page"><div className="channel-head"><img src={c.poster}/><div><h1>{c.name} {c.verified&&"✓"}</h1><p>{c.handle} · {c.subscribers} subscribers · {c.videos} videos</p><p>The official fictional ScaryBox creator channel.</p><button className="btn red">Subscribe</button></div></div><div className="profile-tabs"><b>Home</b><span>Videos</span><span>Shorts</span><span>Live</span><span>Playlists</span></div><Section title="Recent Uploads"><div className="grid">{media.slice(0,6).map(m=><Card key={m.id} m={m}/>)}</div></Section></div>}
function PageHead({title,sub}:{title:string;sub?:string}){return <div className="page-head"><div><h1>{title}</h1>{sub&&<p>{sub}</p>}</div><Search size={22}/></div>}

export default App;
