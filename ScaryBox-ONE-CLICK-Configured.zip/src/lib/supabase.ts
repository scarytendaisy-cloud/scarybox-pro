import { createClient } from "@supabase/supabase-js";

export const supabaseConfigured = true;

export const supabase = createClient(
  'https://estvqkzfddlkbxyuhjgo.supabase.co',
  'sb_publishable_pWE01i4KNnR2NRae7tvtxg_OOTyS0oleyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVzdHZxa3pmZGRsa2J4eXVoamdvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk3MzQyMTQsImV4cCI6MjEwNTMxMDIxNH0.pDEDX3SbJTkPjfDPuhlS2YznulxjyEiz1zgq7LGsJz4',
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true
    }
  }
);
