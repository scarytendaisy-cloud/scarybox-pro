export type Media = {
  id: string; title: string; type: "movie"|"video"|"short"|"live"|"tv";
  poster: string; backdrop?: string; description: string; year: number;
  duration: string; rating: string; genre: string; views: string; channel: string;
  videoUrl?: string; progress?: number;
};

const p = (id: string) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=1200&q=85`;

export const media: Media[] = [
  {id:"m1",title:"The Dark Forest",type:"movie",poster:p("photo-1511497584788-876760111969"),description:"A group of friends enters a mist-covered forest and discovers something far more terrifying than they imagined.",year:2024,duration:"1h 32m",rating:"8.4",genre:"Horror",views:"1.4M",channel:"ScaryBox Official",videoUrl:"https://storage.googleapis.com/coverr-main/mp4/Mt_Baker.mp4"},
  {id:"m2",title:"Ghost Manor",type:"movie",poster:p("photo-1518709268805-4e9042af9f23"),description:"A forgotten mansion wakes after midnight. Every room remembers the people who vanished there.",year:2023,duration:"1h 48m",rating:"7.2",genre:"Horror",views:"982K",channel:"Nightshade Studios"},
  {id:"m3",title:"Revenge Code",type:"movie",poster:p("photo-1485846234645-a62644f84728"),description:"A hunted coder discovers a hidden network that can rewrite the past.",year:2024,duration:"2h 02m",rating:"8.1",genre:"Thriller",views:"731K",channel:"Red Signal"},
  {id:"m4",title:"The Lost City",type:"movie",poster:p("photo-1500534623283-312aade485b7"),description:"A rescue crew follows an impossible signal beneath an abandoned city.",year:2022,duration:"1h 57m",rating:"7.8",genre:"Adventure",views:"654K",channel:"ScaryBox Films"},
  {id:"m5",title:"Silent Hill",type:"movie",poster:p("photo-1500534314209-a25ddb2bd429"),description:"A town with no voices and a road that never leads back.",year:2020,duration:"1h 44m",rating:"7.5",genre:"Mystery",views:"2.1M",channel:"Dark Signal"},
  {id:"m6",title:"The Last Survivor",type:"movie",poster:p("photo-1518391846015-55a9cc003b25"),description:"One survivor. One ruined world. One night to escape.",year:2023,duration:"1h 39m",rating:"8.6",genre:"Action",views:"3.2M",channel:"Afterdark"},
  {id:"m7",title:"Nightmare Island",type:"movie",poster:p("photo-1534447677768-be436bb09401"),description:"A luxury island becomes a trap when the lights go out.",year:2024,duration:"1h 27m",rating:"8.0",genre:"Horror",views:"812K",channel:"Midnight"},
  {id:"m8",title:"The Wanderer",type:"movie",poster:p("photo-1500534623283-312aade485b7"),description:"A stranger walks into a city that has been erased from every map.",year:2021,duration:"1h 51m",rating:"7.7",genre:"Drama",views:"443K",channel:"ScaryBox Films"},
  {id:"v1",title:"The Dark Forest — Trailer",type:"video",poster:p("photo-1511497584788-876760111969"),description:"Official fictional trailer for The Dark Forest.",year:2024,duration:"2:36",rating:"9.1",genre:"Trailer",views:"1.4M",channel:"ScaryBox Official",videoUrl:"https://storage.googleapis.com/coverr-main/mp4/Mt_Baker.mp4"},
  {id:"v2",title:"Horror Shorts Compilation",type:"video",poster:p("photo-1518709268805-4e9042af9f23"),description:"A fictional compilation of short horror moments.",year:2025,duration:"12:48",rating:"8.9",genre:"Horror",views:"892K",channel:"ScaryBox Official"},
  {id:"v3",title:"Gaming With Friends",type:"video",poster:p("photo-1542751371-adc38448a05e"),description:"Late-night co-op gaming and reactions.",year:2025,duration:"48:21",rating:"8.0",genre:"Gaming",views:"210K",channel:"GameZone"},
  {id:"v4",title:"Music & Chill Live Room",type:"live",poster:p("photo-1493225457124-a3eb161ffa5f"),description:"A fictional chill room with music, chat and live visuals.",year:2025,duration:"LIVE",rating:"",genre:"Music",views:"4.8K",channel:"DarkSoul TV"},
  {id:"s1",title:"The Scariest Door",type:"short",poster:p("photo-1519608487953-e999c86e7455"),description:"Would you open it?",year:2025,duration:"0:41",rating:"",genre:"Shorts",views:"124K",channel:"ShadowHorror"},
  {id:"s2",title:"Something Behind Me",type:"short",poster:p("photo-1518837695005-2083093ee35b"),description:"A fictional short horror scene.",year:2025,duration:"0:29",rating:"",genre:"Shorts",views:"91K",channel:"ShadowHorror"}
];

export const channels = [
  {name:"ScaryBox Official",handle:"@ScaryBoxOfficial",subscribers:"1.2M",videos:"542",poster:p("photo-1535713875002-d1d0cf377fde"),verified:true},
  {name:"ShadowHorror",handle:"@ShadowHorror",subscribers:"230K",videos:"128",poster:p("photo-1494790108377-be9c29b29330"),verified:true},
  {name:"GameZone",handle:"@GameZone",subscribers:"84K",videos:"203",poster:p("photo-1500648767791-00dcc994a43e"),verified:false}
];

export const featured = media.slice(0,3);
