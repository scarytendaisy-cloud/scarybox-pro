# ScaryBox — One-Click Configured Build

This version has the supplied Supabase browser credentials already wired into the app, so you do **not** need to create `.env.local` or paste API keys into the source.

## Fastest path

1. Upload this project to a GitHub repository.
2. Import the repository into Cloudflare Pages.
3. Build command: `npm run build`
4. Output directory: `dist`
5. Deploy.

The ScaryBox demo catalog is already included in the app.

## One Supabase step still required

The database tables/RLS/storage setup cannot safely be created by a browser app automatically. In Supabase SQL Editor, run:
- `supabase/migrations/001_scarybox.sql`
- then `supabase/seed_demo.sql`

After that, the app can use authentication, profiles, channels, media, likes, subscriptions, comments, history, playlists, downloads, notifications and live-chat tables.

## Security

The embedded value is the browser/anon-style credential supplied for this project. It is intended for client-side Supabase use; database access must remain protected by RLS. Never replace it with a service-role or secret key.
