# PWABuilder / Android

1. Deploy ScaryBox to HTTPS on Cloudflare Pages.
2. Open the deployed URL in PWABuilder.
3. Confirm the manifest and service worker are detected.
4. Configure Android package metadata, icons and screenshots.
5. Generate the Android package.
6. Test sign-in, navigation, offline shell, video playback, downloads and deep links on a real device.

The PWA can provide the app shell offline. Large video files should be handled with a dedicated offline-download strategy and content rights checks rather than blindly caching every movie.
