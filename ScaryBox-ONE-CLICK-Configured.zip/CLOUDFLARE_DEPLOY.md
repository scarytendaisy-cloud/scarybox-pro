# Cloudflare Pages deployment

1. Push this folder to GitHub.
2. Cloudflare Dashboard -> Workers & Pages -> Create application -> Pages -> import repository.
3. Framework: React/Vite.
4. Build command: `npm run build`.
5. Build directory: `dist`.
6. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` under project environment variables.
7. Deploy.
8. In Supabase Auth settings, add the final `https://YOUR-PAGES-DOMAIN.pages.dev` URL to Site URL/redirect URLs.

Do not upload `.env.local`.
