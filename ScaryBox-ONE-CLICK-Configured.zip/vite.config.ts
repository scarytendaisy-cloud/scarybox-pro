import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      includeAssets: ["icon.svg"],
      manifest: {
        name: "ScaryBox",
        short_name: "ScaryBox",
        description: "Dark movies, videos, shorts and live entertainment.",
        theme_color: "#070707",
        background_color: "#070707",
        display: "standalone",
        orientation: "portrait",
        icons: [
          { src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any maskable" }
        ]
      },
      workbox: {
        navigateFallback: "/index.html",
        runtimeCaching: [
          {
            urlPattern: /^https:\/\/images\.unsplash\.com\/.*/i,
            handler: "CacheFirst",
            options: { cacheName: "scarybox-posters", expiration: { maxEntries: 80, maxAgeSeconds: 2592000 } }
          }
        ]
      }
    })
  ]
});
